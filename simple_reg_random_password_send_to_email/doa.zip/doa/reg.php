<html>
<form name="hehe" action="verify.php" method="post">
First Name: <input type="text" name="fname"/></br>
Middle Name: <input type="text" name="mname" /></br>
Last Name: <input type="text" name="surname"/></br>
Email: <input type="text" name="email" /></br>
Username: <input type="text" name="uname" /></br>
<input type="submit" "value="Register" />

</form>




</html>